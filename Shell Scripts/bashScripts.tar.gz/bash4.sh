#!/bin/bash

echo "Odd numbers from 1 to 20 are : "

for i in $(seq 1 2 20)
do
   echo " $i"
done
      